TAHA SOILING AND CONSTRUCTION — Website + Installable Web App

FILES
- index.html: company website
- manifest.json: installable web app metadata
- sw.js: basic offline cache
- icon.svg: brand icon

HOW TO TEST
1. Extract this ZIP.
2. Open index.html in a browser to preview the website. Some app-install/offline features only work after hosting over HTTPS or using localhost.
3. For a live website, upload the contents to a static web host that supports HTTPS (for example, GitHub Pages or Netlify).
4. After publishing over HTTPS, open the site in Chrome on Android and choose “Install app” / “Add to Home screen”. On iPhone, use Share > Add to Home Screen.

IMPORTANT
- This is an installable Progressive Web App (PWA), not a Play Store APK or native Android app.
- The enquiry form prepares an email in the visitor's email app; it does not store or submit enquiries to a server.
- Business contact details were supplied by the owner. No PAN/GST numbers, registrations, qualifications or completed projects are displayed.
- The JCB is mentioned as company equipment; model and specifications have not been assumed.
- Review all content and confirm legal/business details before public launch.

PAYMENT QR
- payment-qr.jpg contains the payment QR screenshot supplied by the owner.
- The site displays it in a Payment section and instructs customers to verify recipient and amount in their payment app.
